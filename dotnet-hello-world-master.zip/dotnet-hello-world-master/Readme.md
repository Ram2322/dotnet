﻿# Hello World .NET Core Application

# Run locally
```
dotnet run --project hello-world-api
```
Then launch your browser and access http://localhost:5000/api/hello

# Deploy to Cloud Foundry
```
cf push
```
Follow the console output to gather the url
